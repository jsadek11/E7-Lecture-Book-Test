# ENGIN 7 Public Materials for Fall 2025

This repository contains the publicly available materials used in the ENGIN 7 Introduction to Computer Programming for Scientists and Engineers course during the Fall 2025 semester at UC Berkeley.

The contents of this repository are licensed for reuse under [Creative Commons Attribution-NonCommercial 4.0 International (CC BY-NC 4.0)](http://creativecommons.org/licenses/by-nc/4.0/)
